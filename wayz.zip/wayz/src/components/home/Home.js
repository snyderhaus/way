import React, { PureComponent } from "react";

import Works from '../works/Works';

class Home extends PureComponent {
	render() {
		const { handleLoad } = this.props;
		return (
			<div className="Home container text-center">
				<div className="row justify-content-md-center">
					<div className="col-md-10 col-lg-8">
						<h1 className="display-4 animated fadeInDown mb-5">Product Designer</h1>
						<p className="lead animated fadeInDown">‎Currently at McAfee, focusing on Cyber Security and AV Solutions.<br /> Prevously worked as a client-side developer at SIMbiosys.</p>
					</div>
				</div>
				<div className="row">
					<div className="col-md-12">
						<Works handleLoad={handleLoad} />
					</div>
				</div>
			</div>
		);
	}
};

export default Home;