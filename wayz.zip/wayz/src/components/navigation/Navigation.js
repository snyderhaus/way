import React, { PureComponent, Fragment } from 'react';
import { NavLink, withRouter } from 'react-router-dom';
import ReactTooltip from 'react-tooltip'

import Tooltip from '../_generic/tooltip/Tooltip';

import { WithContext } from '../../context/WithContext';

import logo from '../../van.svg';

class Navigation extends PureComponent {
	state = {
		show: true,
		top: true,
		small: false
	}

	handleScrollBottom = () => {
	window.scrollTo(0, document.body.scrollHeight);
	}

	handleScrollTop = () => {
		window.scrollTo(0, 0);
	}

	handleScroll = () => {
		let previousPosition = window.pageYOffset || document.documentElement.scrollTop;
		window.onscroll = () => {
			let currentPosition = window.pageYOffset || document.documentElement.scrollTop;
			this.setState({
				scroll: previousPosition < currentPosition,
				top: currentPosition <= 25
			});
			
			previousPosition = currentPosition;
		};
	}

	handleClick = () => {
		this.props.handleLoad();
	}

	componentDidMount() {
		this.handleScroll();
		if (window.outerWidth < 768) {
			this.setState({
				small: true
			});
		}
	}

	render() {
		const { scroll, top, small } = this.state;
		const { pathname } = this.props.location;
		return (
			<Fragment>
				{small && pathname === "/" && 
					<div className={`mobile animated fadeInDown`}>
						<NavLink to="/" onClick={this.handleClick} className="navbar-brand mx-auto mx-md-0 mt-md-0">
							<img src={logo} alt="vancrox" data-tip="Return to Works" data-place="bottom" />
						</NavLink>
					</div>
				}
				{small && pathname !== "/" && 
					<div className={`navline d-flex fixed-top py-3 animated fast ${!top && scroll ? 'fadeOutUp' : 'fadeInDown'} ${top ? 'is_top' : ''}`}>
						<NavLink to="/" onClick={this.handleClick} className="navbar-brand mx-auto mx-md-0 mt-md-0">
							<Tooltip output="Head home">
								<img src={logo} alt="vancrox" data-tip="Return to Work" data-place="bottom"/>
							</Tooltip>
						</NavLink>
					</div>
				}
				{!small &&
					<div className={`navline d-none d-md-flex faster ${pathname !== '/' ? 'fixed-top' : ''} animated ${!top && scroll ? 'fadeOutUp' : 'fadeInDown'} ${top ? 'is_top' : ''}`}>
						<nav className={`Navigation navbar navbar-expand-md container py-3`}>
							<NavLink to="/" onClick={this.handleClick} className="navbar-brand mx-auto mx-md-0 mt-md-0">
								<img src={logo} alt="vancrox" data-tip="Return to Works" data-place="bottom" data-effect="solid" />
							</NavLink>
							<ul className="navbar-nav ml-auto">
								<li className="nav-item">
									<NavLink to="/" className="nav-link" onClick={this.handleClick}>Work</NavLink>
								</li>
								<li className="nav-item">
									<a className="nav-link" target="_blank" href="../images/cv.pdf">Resume</a>
								</li>
								<li className="nav-item">
									<a className="nav-link" onClick={this.handleScrollBottom}>Contact</a>
								</li>
							</ul>
						</nav>
					</div>
				}
				<ReactTooltip />
				<button className={`topper animated faster ${top ? 'fadeOutDown' : 'fadeInUp'}`} onClick={this.handleScrollTop}><i className="fas fa-chevron-up" /></button>
			</Fragment>
		);
	}
};

export default WithContext(withRouter(Navigation));