import React, { Component, Fragment } from 'react';
import { Route, Switch } from "react-router-dom";
import { TransitionGroup, Transition } from 'react-transition-group';
import Navigation from '../navigation/Navigation';
import Home from '../home/Home';
import Overview from '../overview/Overview';
import Footer from '../footer/Footer';
import Loader from '../_generic/loader/Loader';
import { instanceOf } from 'prop-types';
import { withCookies, Cookies } from 'react-cookie';
import Password from '../password/Password';

import { WithContext } from '../../context/WithContext';

class Main extends Component {
	static propTypes = {
		cookies: instanceOf(Cookies).isRequired
	}

	state = {
		loggedIn: this.props.cookies.get('loggedIn')
	}

	handleLogin = loggedIn => {
		const { cookies } = this.props;
	 
		cookies.set('loggedIn', loggedIn, { path: '/' });
		this.setState({ loggedIn });
	}

	validate = pass => {
		if (pass === 'QWERTY') { // this ain't no bank, look away!
			this.handleLogin(true);
		}
	}

	render() {
		const { location, handleLoad } = this.props;
		const { pathname, key } = location;
		const { theme, loading } = this.props.context;
		const { loggedIn } = this.state;

		return (
			<div className={`Main ${theme ? 'theme-dark' : ''}`}>
				{!loggedIn 
					? <Password validate={this.validate} /> 
					: (
						<Fragment>
							<Navigation handleLoad={this.props.handleLoad} />
							<TransitionGroup component={null}>
								<Transition
									key={key}
									timeout={{enter: 750, exit: 150}}
									className="fade"
								>
									<Switch location={location}>
										<Route exact path="/" render={() => <Home handleLoad={handleLoad} />} />
										<Route exact path="/overview/:id" component={Overview} />
										<Route render={() => <h1 className="text-center py-5 my-5">Not Found!</h1>} />
									</Switch>
								</Transition>
							</TransitionGroup>
							<Footer />
						</Fragment>
					)
			
				}
			</div>
		);
	}
}

export default withCookies(WithContext(Main));
