import React, { PureComponent, Fragment } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route } from 'react-router-dom';
import * as serviceWorker from './serviceWorker';
import ContextProvider from './context/context';
import { CookiesProvider } from 'react-cookie';
import Password from './components/password/Password';
import Loader from './components/_generic/loader/Loader';
import Main from './components/main/Main';
import Navigation from './components/navigation/Navigation';

import './index.scss';

class App extends PureComponent {

	state = {
		loading: true
	}

	componentDidMount() {
		setTimeout(() => {
			this.setState({ loading: false });
		} , 2500);
	}

	handleLoad = () => {
		this.setState({ loading: true });
		setTimeout(() => {
			this.setState({ loading: false });
		} , 1000);
	}

	render() {
		const { loading } = this.state;
		return (
			<CookiesProvider>
				<ContextProvider>
					<BrowserRouter>
						<Route render={({ location }) => (
							<Fragment>
								{loading ? <Loader /> : <Main location={location} handleLoad={this.handleLoad} />}
							</Fragment> 
						)} />
					</BrowserRouter>
				</ContextProvider>
			</CookiesProvider>
		);
	}
};

ReactDOM.render(
	<App />, 
	document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.register();
